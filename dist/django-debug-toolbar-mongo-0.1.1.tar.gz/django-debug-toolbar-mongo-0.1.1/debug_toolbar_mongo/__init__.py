# following PEP 386, versiontools will pick it up
__version__ = (0, 1, 10, "final", 0)

from .panel import MongoPanel