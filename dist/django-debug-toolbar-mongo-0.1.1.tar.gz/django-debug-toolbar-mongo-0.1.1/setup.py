# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['debug_toolbar_mongo', 'debug_toolbar_mongo.templatetags']

package_data = \
{'': ['*'], 'debug_toolbar_mongo': ['templates/*']}

install_requires = \
['Django>=4.1.1,<5.0.0',
 'django-debug-toolbar>=3.6.0,<4.0.0',
 'pymongo>=4.2.0,<5.0.0',
 'tqdm>=4.64.1,<5.0.0']

setup_kwargs = {
    'name': 'django-debug-toolbar-mongo',
    'version': '0.1.1',
    'description': '',
    'long_description': '\n# Django Debug Toolbar MongoDB Panel\n\n## Install\n\n```\npoetry add git+https://github.com/CrazyPilot/django-debug-toolbar-mongo.git --group dev\n```\n\n## Setup\n\nAdd the following lines to your `settings.py`:\n\n```python\n   INSTALLED_APPS = (\n       ...\n       \'debug_toolbar_mongo\',\n       ...\n   )\n\n   DEBUG_TOOLBAR_PANELS = (\n       ...\n       \'debug_toolbar_mongo.MongoPanel\',\n       ...\n   )\n```\n\nAn extra panel titled "MongoDB" should appear in your debug toolbar.',
    'author': 'Antonio',
    'author_email': 'mr.antonsilin@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
